from odoo import api, fields, models, _

class FleetDriverAssignWizard(models.TransientModel):
    _name = 'fleet.driver.assign.wizard'
    _description = 'Assign Driver to Booking'
    
    booking_id = fields.Many2one(
        'fleet.booking', 
        string='Booking', 
        required=True,
        ondelete='cascade'
    )
    driver_id = fields.Many2one(
        'fleet.driver', 
        string='Driver', 
        required=True,
        domain=[('state', '=', 'available')],
        ondelete='cascade'
    )
    note = fields.Text(string='Assignment Note')
    
    def action_assign(self):
        self.ensure_one()
        if self.driver_id and self.booking_id:
            self.booking_id.write({
                'driver_id': self.driver_id.id,
            })
            # Update driver status
            self.driver_id.action_set_on_trip()
            # Create a note in the chatter
            if self.note:
                self.booking_id.message_post(body=_("Driver %s assigned: %s") % 
                                           (self.driver_id.name, self.note))
            else:
                self.booking_id.message_post(body=_("Driver %s assigned to this booking.") % 
                                           self.driver_id.name)
        return {'type': 'ir.actions.act_window_close'}