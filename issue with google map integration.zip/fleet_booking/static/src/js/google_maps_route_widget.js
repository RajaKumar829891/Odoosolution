/** @odoo-module **/

import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import { Component, useRef, onMounted, onPatched, onWillUnmount } from "@odoo/owl";

/**
 * Google Maps Route Widget
 * Displays a route between two points with Google Maps
 */
export class GoogleMapsRouteWidget extends Component {
    static template = 'fleet_booking.GoogleMapsRouteWidget';
    static props = {
        record: { type: Object },
    };

    setup() {
        this.mapRef = useRef("map");
        this.orm = useService("orm");
        this.notification = useService("notification");
        
        this.map = null;
        this.markers = [];
        this.directionsService = null;
        this.directionsRenderer = null;
        this.googleMapsLoaded = false;

        // Initialize when component mounts
        onMounted(() => this.initGoogleMaps());
        
        // Update when record changes
        onPatched(() => {
            if (this.googleMapsLoaded && this.recordHasLocationData()) {
                this.updateMap();
            }
        });
        
        // Cleanup on unmount
        onWillUnmount(() => this.destroyMap());
    }
    
    /**
     * Initialize Google Maps and related services
     */
    async initGoogleMaps() {
        try {
            // Fetch API key from system parameter
            const apiKey = await this.getGoogleMapsApiKey();
            
            if (!apiKey) {
                this.showApiKeyError();
                return;
            }
            
            // Load Google Maps API
            await this.loadGoogleMapsScript(apiKey);
            this.googleMapsLoaded = true;
            
            // Initialize the map
            this.initMap();
            
            // Show route if we have location data
            if (this.recordHasLocationData()) {
                this.updateMap();
            }
        } catch (error) {
            console.error("Failed to initialize Google Maps:", error);
            this.showGoogleMapsError(error);
        }
    }
    
    /**
     * Initialize the map with default settings
     */
    initMap() {
        if (!this.mapRef.el) return;
        
        // Create the map
        this.map = new google.maps.Map(this.mapRef.el, {
            zoom: 5,
            center: { lat: 20.5937, lng: 78.9629 }, // Center of India
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            mapTypeControl: true,
            fullscreenControl: true,
            streetViewControl: false,
        });
        
        // Initialize directions services
        this.directionsService = new google.maps.DirectionsService();
        this.directionsRenderer = new google.maps.DirectionsRenderer({
            map: this.map,
            suppressMarkers: false,
            polylineOptions: {
                strokeColor: '#4285F4',
                strokeWeight: 5,
                strokeOpacity: 0.8
            }
        });
        
        // Add debug message
        console.log("Google Maps initialized successfully");
    }
    
    /**
     * Update the map based on record data
     */
    updateMap() {
        if (!this.map || !this.directionsService || !this.directionsRenderer) {
            return;
        }
        
        const record = this.props.record.data;
        
        // Clear previous markers
        this.clearMarkers();
        
        // Check which approach to use based on available data
        if (record.polyline) {
            // Use polyline if available
            this.displayPolyline(record.polyline);
        } else if (record.start_latitude && record.start_longitude && 
                  record.end_latitude && record.end_longitude) {
            // Use coordinates if available
            this.displayRouteFromCoordinates(
                record.start_latitude, record.start_longitude,
                record.end_latitude, record.end_longitude
            );
        } else if (record.start_location && record.end_location) {
            // Use location names
            this.calculateAndDisplayRoute(record.start_location, record.end_location, record.via_stops);
        } else {
            console.warn("Insufficient data to display route");
        }
    }
    
    /**
     * Display route using encoded polyline
     * @param {string} polyline - Encoded polyline string
     */
    displayPolyline(polyline) {
        if (!polyline) return;
        
        try {
            // Decode the polyline
            const path = google.maps.geometry.encoding.decodePath(polyline);
            
            // Create a polyline object
            const routePath = new google.maps.Polyline({
                path: path,
                geodesic: true,
                strokeColor: '#4285F4',
                strokeOpacity: 0.8,
                strokeWeight: 5
            });
            
            // Clear directions renderer
            this.directionsRenderer.setMap(null);
            
            // Add the polyline to map
            routePath.setMap(this.map);
            
            // Add markers for start and end points
            if (path.length > 0) {
                this.addMarker(path[0], 'Start', 'green');
                this.addMarker(path[path.length - 1], 'End', 'red');
                
                // Fit bounds to include the entire route
                const bounds = new google.maps.LatLngBounds();
                path.forEach(point => bounds.extend(point));
                this.map.fitBounds(bounds);
            }
        } catch (error) {
            console.error("Error displaying polyline:", error);
        }
    }
    
    /**
     * Display route using start and end coordinates
     */
    displayRouteFromCoordinates(startLat, startLng, endLat, endLng) {
        const start = new google.maps.LatLng(startLat, startLng);
        const end = new google.maps.LatLng(endLat, endLng);
        
        // Add markers
        this.addMarker(start, 'Start', 'green');
        this.addMarker(end, 'End', 'red');
        
        // Calculate route
        this.directionsService.route({
            origin: start,
            destination: end,
            travelMode: google.maps.TravelMode.DRIVING
        }, (response, status) => {
            if (status === 'OK') {
                this.directionsRenderer.setDirections(response);
            } else {
                console.error('Directions request failed due to', status);
                this.notification.add(
                    `Failed to calculate route: ${status}`,
                    { type: 'danger' }
                );
                
                // If directions fail, at least show markers
                const bounds = new google.maps.LatLngBounds();
                bounds.extend(start);
                bounds.extend(end);
                this.map.fitBounds(bounds);
            }
        });
    }
    
    /**
     * Calculate and display route using location names
     */
    calculateAndDisplayRoute(startLocation, endLocation, viaStops) {
        if (!startLocation || !endLocation) return;
        
        // Parse via stops if present
        let waypoints = [];
        if (viaStops) {
            waypoints = viaStops.split('\n')
                .filter(stop => stop.trim())
                .map(stop => ({
                    location: stop.trim(),
                    stopover: true
                }));
        }
        
        // Request route
        this.directionsService.route({
            origin: startLocation,
            destination: endLocation,
            waypoints: waypoints,
            optimizeWaypoints: false,
            travelMode: google.maps.TravelMode.DRIVING
        }, (response, status) => {
            if (status === 'OK') {
                this.directionsRenderer.setDirections(response);
                
                // Extract route details
                const route = response.routes[0];
                if (route && route.legs && route.legs.length > 0) {
                    // Could update record with calculated values if needed
                }
            } else {
                console.error('Directions request failed due to', status);
                this.notification.add(
                    `Failed to calculate route: ${status}`,
                    { type: 'danger' }
                );
            }
        });
    }
    
    /**
     * Add a marker to the map
     */
    addMarker(position, title, color = 'red') {
        const marker = new google.maps.Marker({
            position: position,
            map: this.map,
            title: title,
            icon: {
                path: google.maps.SymbolPath.CIRCLE,
                fillColor: color,
                fillOpacity: 0.8,
                strokeColor: 'white',
                strokeWeight: 2,
                scale: 8
            }
        });
        
        this.markers.push(marker);
    }
    
    /**
     * Clear all markers from the map
     */
    clearMarkers() {
        this.markers.forEach(marker => marker.setMap(null));
        this.markers = [];
    }
    
    /**
     * Check if record has required location data
     */
    recordHasLocationData() {
        const record = this.props.record.data;
        
        return record && (
            record.polyline ||
            (record.start_latitude && record.start_longitude && 
             record.end_latitude && record.end_longitude) ||
            (record.start_location && record.end_location)
        );
    }
    
    /**
     * Get Google Maps API key from system parameters
     */
    async getGoogleMapsApiKey() {
        try {
            const apiKey = await this.orm.call(
                'ir.config_parameter', 
                'get_param', 
                ['fleet_booking.google_maps_api_key']
            );
            return apiKey;
        } catch (error) {
            console.error("Error fetching Google Maps API key:", error);
            return null;
        }
    }
    
    /**
     * Load Google Maps API script
     */
    loadGoogleMapsScript(apiKey) {
        return new Promise((resolve, reject) => {
            // Check if API is already loaded
            if (window.google && window.google.maps) {
                resolve();
                return;
            }
            
            // Create callback function
            window.initGoogleMaps = function() {
                resolve();
            };
            
            // Create script element
            const script = document.createElement('script');
            script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places,geometry&callback=initGoogleMaps`;
            script.async = true;
            script.defer = true;
            
            // Handle errors
            script.onerror = function() {
                reject(new Error('Failed to load Google Maps API'));
            };
            
            // Add to document
            document.head.appendChild(script);
        });
    }
    
    /**
     * Show error when API key is missing
     */
    showApiKeyError() {
        this.notification.add(
            'Google Maps API key is not configured. Please set it in Settings > Fleet Booking.',
            {
                type: 'danger',
                title: 'Missing API Key',
                sticky: true
            }
        );
        
        if (this.mapRef.el) {
            this.mapRef.el.innerHTML = `
                <div class="alert alert-danger text-center m-3">
                    <i class="fa fa-exclamation-triangle me-2"></i>
                    <strong>Google Maps API key is missing</strong>
                    <p class="mt-2 mb-0">Please configure the API key in Settings &gt; Fleet Booking</p>
                </div>
            `;
        }
    }
    
    /**
     * Show Google Maps error message
     */
    showGoogleMapsError(error) {
        this.notification.add(
            `Error loading Google Maps: ${error.message}`,
            {
                type: 'danger',
                title: 'Google Maps Error',
            }
        );
        
        if (this.mapRef.el) {
            this.mapRef.el.innerHTML = `
                <div class="alert alert-danger text-center m-3">
                    <i class="fa fa-exclamation-triangle me-2"></i>
                    <strong>Failed to load Google Maps</strong>
                    <p class="mt-2 mb-0">${error.message}</p>
                </div>
            `;
        }
    }
    
    /**
     * Cleanup resources
     */
    destroyMap() {
        this.clearMarkers();
        if (this.directionsRenderer) {
            this.directionsRenderer.setMap(null);
        }
        this.map = null;
        this.directionsService = null;
        this.directionsRenderer = null;
    }
}

// Register the widget
registry.category("view_widgets").add("google_maps_route", GoogleMapsRouteWidget);

export default GoogleMapsRouteWidget;