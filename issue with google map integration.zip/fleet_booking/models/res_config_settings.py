from odoo import api, fields, models

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'
    
    google_maps_api_key = fields.Char(
        string='Google Maps API Key',
        config_parameter='fleet_booking.google_maps_api_key'
    )
    
    auto_calculate_route_details = fields.Boolean(
        string='Auto Calculate Route Details',
        config_parameter='fleet_booking.auto_calculate_route_details',
        default=True
    )
    
    default_distance_uom = fields.Selection(
        [('km', 'Kilometer'), ('mile', 'Mile')],
        string='Default Distance UOM',
        config_parameter='fleet_booking.default_distance_uom',
        default='km'
    )
    
    auto_calculate_price = fields.Boolean(
        string='Auto Calculate Price',
        config_parameter='fleet_booking.auto_calculate_price',
        default=True
    )
    
    default_vat_percentage = fields.Float(
        string='Default VAT Percentage',
        config_parameter='fleet_booking.default_vat_percentage',
        default=18.0
    )
    
    distance_uom = fields.Selection(
        [('km', 'Kilometer'), ('mile', 'Mile')],
        string='Distance Unit',
        config_parameter='fleet_booking.default_distance_uom',
        default='km'
    )