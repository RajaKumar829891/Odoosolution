# -*- coding: utf-8 -*-
from . import qcent_res_partner_attachment_inherit
from . import qcent_sale_order_attachment_inherit
from .  import qcent_sale_order_line_attachment_inherit
