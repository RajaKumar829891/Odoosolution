{
    'name': 'MyOperator Integration',
    'version': '17.0.1.0.0',
    'category': 'CRM',
    'summary': 'Integrate MyOperator call and WhatsApp services with Odoo',
    'description': """
        MyOperator Integration Module for Odoo
        =====================================
        
        This module integrates MyOperator call and WhatsApp services with Odoo.
        Features:
        - Configure MyOperator API credentials
        - Sync call logs from MyOperator
        - Sync WhatsApp messages from MyOperator
        - Make outbound calls directly from Odoo
        - Send WhatsApp messages directly from Odoo
        - Link customers with their communication history
    """,
    'author': 'Your Company',
    'website': 'https://www.yourcompany.com',
    'depends': [
        'base',
        'contacts',
        'mail',
        'web',
    ],
    'data': [
        'security/myoperator_security.xml',
        'security/ir.model.access.csv',
        'data/ir_cron_data.xml',
        'data/server_actions.xml',
        'data/myoperator_data.xml',
        'wizard/views/myoperator_sync_wizard_views.xml',
        'wizard/views/myoperator_whatsapp_wizard_views.xml',
        'views/myoperator_config_views.xml',
        'views/myoperator_call_views.xml',
        'views/myoperator_message_views.xml',
        'views/res_partner_views.xml',
        'views/menu_views.xml',
    ],
    'assets': {
        'web.assets_backend': [
            # Only include essential JavaScript and CSS
            'myoperator_integration/static/src/css/myoperator_style.css',
        ],
    },
    'demo': [],
    # Base64-encoded small telephone icon
    'icon': 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAADsQAAA7EB9YPtSQAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAA12SURBVHic7Z15cBzVGcC/b2Z2V7J1WD7kQ7INtjFgTI2BmhBzmEAMTDgypOmETqdMpp1JQiZMQ9NkMmmTYTKZHkyHKZOQNFOGUoczkJDAUAiYBggE7BiMwRdgI9mWbVk6dlfS7r79o1Zgy9Zqu2/fHtbvn93V7vve+/a737773vcOwhTjlhRf7HZcLbLLtZxFl4NEF4PIBEqUgGoBxV8AeQ7gGYCnQXkaoDshccOUwYaX5zaO9pf7OipBSHcBSuXmlV6fMz51tYicJaJsEGCpCEixvwWQfgBvgcibLLx15p0137Io6bJScQo4Y+UK/8hI6GIR/RIRLoUoKDnRMsUPwO8A/q1KQrUvz248bPOvlUVFKODGVatnOLjqiyxwE4jmqsqHCPaJ6M4aV/i375/feEJVPuWgWAE3r/Lmjod4JUvyMxB1qMwrFTbDPUB63+fvqnlbdV62K+CW1d7zWPA9AExXmU+GHBGEO+rcw1t2bxgZVpWJbQq48WxvzfgEvw3gKyAY9uVbCAs+QIK/qff0bFO1JDRdAXesbZsV9vXcw8DXQeRWlUeZiLEI/qe2Z/YLm5uOT6hI3lQFPLB+zVxCcA+ELzVTpjYTB3C3Jzh8z66NJ/vtTtxWBdyxekubI9j9XQDfBaDb4/hVTZgId3pCJ/+0a+Nw2M6EbVHA3WtXLmZJ7gPRx+1IvzIRefPz9x1+0c5ULS9k6+o1Z4nj+BEIOktOK0eEwL+5Pc4rH7n3Tds0YFkN0Lpq9VcZjscB5NRD7xYE1U5Z84lH7m20QwGWdNNaVy1XHFQ/AsBpRXpTlREQXVrvGdxWagIlT7taPbffXFv3HARWlprWtEbk9frg8K9LtRUUPQdoXbdGaxlY+xcGX152uaahhPUj8NC+Ox58pth0iroD9Nt9vwLwpeKLNY0R4a06T9/FxWQBlOwNqPPMfZAFP2dmM5Y/cyBCb6lmVbGvT8w6OkCr8c0E2ib6IyCrALQUm+5UgkVHcBx3vf+1n/aWUo5CNeDGVatnOKnqVQAtcZ93Aji9lIJMVVhktNYzOOORew+UnEYxF7/BOfwLEGQu/p4HUF1qQaYoDBI54/17NxUlAMPv8tdsaA6G6GlxhM+ctnVwgf7JxTBGQQrY0ByMjI08CMCl3w5GBZpg4MqVt/Vp751b1DDM0Dugzd+5nVn3eV33z+DsiDi3b249Otlo/ZAK6PCH5oVD8kcQjst0gYC5ADx2FPIjjLBg50v+3vmTDRhOpoCODe7aQFB+KYKZGR44aXSuZWR5E7G2Q7QT09kBr1y1zul21j0MQtaZOXFQQVMH2yAiLJLs9Qy/svP5rIPETAroN9CDBMw5xX0qbcwwOZKh/uGsY6YzDrOODT3XMeBj3V0/PRCARQbS90pnmgN0rq8PgnGLJp3nqLEbkVBvZnPGGqCjwz3LE+KHQbR2Mv8/MWCNAI2i8f6TLwC4LF2W6RXq8gZtLFlFMdoXiuZyJ1TADc3B2lCYH6bJik9EeXTKnw7k6oOlVkDKJqBtqv9wKSCoAYgmLHam20D/BncdCF8rpFSV1gxkg8GxGQ9nXHSb0BLYsV53E8BXFF6q3MswCbI4fGiGgY4rMj78nFABIw5cB0JdoQWaSrdBJvriI3etmTCVY3djwO0PLA7HZDcIxU3BTiWhKLCQKxgdqw1l/GDsmqf+otXfuYULLb7RbSkUlUQfPxjIYB6JXfNYDYQiTQCgF1O0KUn/8XH5JK65UwFufyx95hA77wCxSVv3TCVYEAzHZZaY6JrH3jvswPYB18KDXTp93VabQgxh5AxHgzXp10+5A9r8IxcJoKeQhKwQ30Ro85VShTI3KUqJCLojtK4m3SBY2vRmQNu5Pti6qVmDNHNXLVa/8LgJJBFE4pKWTvyaEwHrhO0yAWRqkCbhDMW/7o8fj10zpoC6oPtsBirQBaKMRsAUhgQDo7JoRqLNZUwBteKeTyJqNmUzSEaMSWCx2URVw3gqCAYAoDrx54xOILvmFKrAsHsphgS6y1dNBRJTRCLjFt4JAJDIvEBihJQSCrn4k4WZCK6qGQHD4l+X8S8QHVJeGLth0f7JQ5XfBNgLEzyd9oaImMnkJZjEGyCPDK5yI8V3jc0BGBiWpBVw6rXkm7FrdpRICUqq7USZZnMQkfF1kckNUHYJIRCj6nQVIdlnimDsDlDXBaykTh55Hq2hpuUAFoIbP6m3NDKMQAWbgAqrZEshEhxKdrIYV0C+3S1FksjFrzLuADVRbPcQT9eowEoxJlQGRTAgWHcEHPRaAQDgT8TJXANGx+sBZl0TQGkZkRidQ2IpJrAxAZjc/JyKlE1yU0hTIo5x9wQwLXW3+Clj+cokUw1gTEWRVK2JrwFYmTHM4vwpkxuCZaMqBVw2UKPVk8KCLQxJIzZf0BJURF8IAJi5W9Xafy66PqBaRgxQFU++7T3G9YB4rErZPIBNMcCTPM5PzJchWdNYG8PN0+lZZVh2Y5VIHGM2AV1qZuyjcnRdM5HgAi5XlCmOKZsaYzsCMHZhxgG8p64QKmoBZZqGrAYGDspYAQCgZ/5bKUhQNiQwbMnAZWS0AxzbTGLZ4hCZasA0Q0MXIvyGiHwMABCm/oM8CJjSLgkjcU3G7wD5WuQaF1cT+GjEsLFr+bL0/sAMSR89a4X9XD6Xd1TxFaRtCeQcLgkV76aIDYFJ2X12dZIeC8cmiD9iM+1CUOR+zozb+DpJJ3zJ5qEJ+4JUWbGmuFNgspSsrOTHTYl3FuXcE3gyNfTcAzA/k2aVPh2+AnIYoiVcDGlrgFjF1gHEuiOYhQ0ORtDdE1D3Pl4pSm8OaQ5rPGx6wd0dRFpCGt/jT98/9A4NVrXoKlvlwGK/v8vtZGzGRrVPd4G8A0FV7m2UxG8dO54sWyxuSxd5rOuqwehL1cwJ1ILb4U7rA1JTGDsuqQKAqJ0bZGYYYrxm27lBpmiMDPUNZJMbMMELEYn17gaRqE6yiiuGwLkXNWfjHCpDYcQY3Z3oAE4QYE9qiPHrAJ9k4MtTrN7KlHQzsAYJpA1D9zJ4vLcJ1pTvLlh/I6OCKAaIuM6a0XEULyO6MqowCGXlG0+/kNGVQXdccrvPxcTZJsQqX4U58gHBi4D8ON1FYxIFdP9hfjjmmPe0CO4CSKWKyjmAn7iOPd9wYvGJTO9mvAM0N7tbw3GcB0JbAY+LDKJ2CrbsWGo2LQxDWCaZk6WbcGnYpLnp0VBw9JlsEjnlB5L7Prv7TRac3/6ePDFFfFiXbg8vBiV2bZhxQ4hIMHQfCFmHfuJo6YPFK8kWwQQQsAwCHb94y+NZOz5OqoDdtwbnRxxzHosK7oSgqIXMqWIbZEGAeENt6PirO3b0ZN0uDABYcnwpnTfX6x8WHAXDl9LcB8OVdwdQCoOEYlQ1e0b19Qfu7cw1IK+uLh5wt0YM3MWCTeYXUVkRRRgUAMZXXmJqf3FLd1e+Y/NWwO7mwBKDnbtY+E4ANTPnDpQOARkhhf0NglC3NtP1wAv3Hx0pJL2CFbC7RZ8VN1zXs+ANFtyUuhqLLpfvBBKkLoFJH1RA8sN5XUP/fbjpyGih6RUsZU7tF+ofCztXpEZRu8BoINGYXMZtBQaI4H2QSz8Rnd35wDuHnprIupeLohWwu7nn1pjgWyI8HwxN4lMCgwkkekiE+rxVXY882pThVW4DRStgV3Nve9zA9Sx0PQgJY9yEzh4i0g3Qr9yahh0PNYcOmp+i/RTtCNp5Y3DWeAT3MeALJ0csJy/JkZGYhGDHVnw8QMkK2HljMCMWoddSO4oOGTjB2Ym8QSIBR3T8g/0bjh6yo1x2UHI3cOfGYOMYHbqfCOemv+8sZOFlYsYfUCNGUZPE/ZV4lw8sGoHu3BjwyNj8uxiwSYCqdPL0KWcxRLgHNbJxx0bfhN5A1dicnVU5w0p+KaHORMImwH8iN/6pTgZ+g4T+vWdd/nHd5bCbkmuAVO7c6L/WgNzOgiqD4rNS5/+J3wVSDfM+XmUR7Vta7uSndC2dGFP2DXR/8+xGAKe+Ox7HgHCDJnT+/t2Tx2kTcE4twAIXbGn7Ogu+rbss5cAu8iHMIXBefH6dOg4LKGoI6vCHviksGyGcZcQOgNJ8UyFBRO7w4MivnCJ37n8kGNU93JoqoiaAJkW9OTZRuTfQBrY2+5cZxLcReIXuslgIC25xROih/Rs8++xaSi4lSt0AnVv1wGKD6bHU2sDpdvyjUX/wvQd3gOiRnZ9zW77bJ4cApXOA9cHGeUPRbwxJZKUAnsrfOdwogl4R3KU57F37/h0K6y5TuShRwGmt/vo6XlLj1a+Mji+JIfwRAp0KotBE3yFMKM2vDNRvQoFt9QcGfz/VfgTsVEr6YyhqonXuxuaJvj+RRLU/OAQAU8UrZ6oCcjEFbYJ//w/XBJIgoxJplAAAAABJRU5ErkJggg==',
    'installable': True,
    'application': True,
    'auto_install': False,
    'license': 'LGPL-3',
}