from . import myoperator_sync_wizard
from . import myoperator_whatsapp_wizard