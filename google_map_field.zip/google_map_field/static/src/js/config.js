/** @odoo-module **/
export const GOOGLE_MAP_URL = "https://maps.googleapis.com/maps/api/js?libraries=places,geocoding&key=";