import json
import logging
import requests
from datetime import datetime, timedelta
from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError

_logger = logging.getLogger(__name__)

class MyOperatorConfig(models.Model):
    _name = 'myoperator.config'
    _description = 'MyOperator Configuration'

    name = fields.Char('Name', required=True)
    api_token = fields.Char('API Token', required=True, help="API token from MyOperator panel")
    api_url = fields.Char('API URL', default='https://in.app.myoperator.com/api', required=True, 
                         help="MyOperator API endpoint")
    webhook_url = fields.Char('Webhook URL', default='https://yourserver.com/myoperator/webhook', 
                             help="URL that will receive events from MyOperator")
    is_active = fields.Boolean('Active', default=True)
    company_id = fields.Many2one('res.company', string='Company', required=True, 
                                default=lambda self: self.env.company)
    last_call_sync = fields.Datetime('Last Call Sync', readonly=True)
    last_message_sync = fields.Datetime('Last Message Sync', readonly=True)
    auto_sync = fields.Boolean('Auto Synchronize', default=True)
    sync_interval = fields.Selection([
        ('15', '15 minutes'),
        ('30', '30 minutes'),
        ('60', '1 hour'),
        ('360', '6 hours'),
        ('720', '12 hours'),
        ('1440', '24 hours'),
    ], string='Sync Interval', default='60')
    
    # Connection status tracking
    connection_status = fields.Selection([
        ('not_tested', 'Not Tested'),
        ('connected', 'Connected'),
        ('failed', 'Connection Failed')
    ], string='Connection Status', default='not_tested')
    last_error = fields.Text('Last Error', readonly=True)
    last_checked = fields.Datetime('Last Checked', readonly=True)
    webhook_secret = fields.Char('Webhook Secret', help="Secret key used to validate incoming webhooks")
    
    _sql_constraints = [
        ('name_uniq', 'unique(name, company_id)', 'Configuration name must be unique per company!')
    ]
    
    @api.constrains('api_token')
    def _check_api_token(self):
        for record in self:
            if not record.api_token:
                raise ValidationError(_("API Token is required!"))
    
    def action_test_connection(self):
        """Test the connection to MyOperator API"""
        self.ensure_one()
        
        try:
            # Build API URL - using the integration/public_api endpoint shown in your screenshot
            api_url = self.api_url
            
            # MyOperator might be using different authentication methods
            # Let's try multiple methods to identify the correct one
            
            # Method 1: API Key in Header
            headers1 = {
                'X-API-KEY': self.api_token,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
            
            # Method 2: Bearer Token
            headers2 = {
                'Authorization': f'Bearer {self.api_token}',
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
            
            # Method 3: Basic Auth (if token is username:password format)
            try:
                import base64
                auth_header = base64.b64encode(self.api_token.encode()).decode()
                headers3 = {
                    'Authorization': f'Basic {auth_header}',
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            except:
                headers3 = {}
            
            # Method 4: API Key as Query Parameter
            query_url = f"{api_url}?api_key={self.api_token}"
            
            # Method 5: Auth as query parameter
            query_url2 = f"{api_url}?auth={self.api_token}"
            
            # Method 6: Token as query parameter (as in original code)
            query_url3 = f"{api_url}?token={self.api_token}"
            
            # Log attempt details
            _logger.info("Testing connection to MyOperator API: %s", api_url)
            
            # Try different endpoints to find one that works
            test_endpoints = [
                "", # base URL
                "/status",
                "/v1/status",
                "/account/info",
                "/v1/account",
                "/user/info",
                "/auth/verify"
            ]
            
            # Try to find a working endpoint and authentication method
            results = []
            success = False
            
            # Test all combinations of headers and endpoints
            for endpoint in test_endpoints:
                full_url = api_url + endpoint if endpoint else api_url
                
                # Try with API Key in Header
                try:
                    response = requests.get(full_url, headers=headers1, timeout=10)
                    if response.status_code == 200:
                        _logger.info("Success with API Key header at %s", full_url)
                        results.append((response, "API Key header", full_url))
                        success = True
                        break
                except Exception as e:
                    _logger.debug("Failed with API Key header at %s: %s", full_url, str(e))
                
                # Try with Bearer Token
                try:
                    response = requests.get(full_url, headers=headers2, timeout=10)
                    if response.status_code == 200:
                        _logger.info("Success with Bearer token at %s", full_url)
                        results.append((response, "Bearer token", full_url))
                        success = True
                        break
                except Exception as e:
                    _logger.debug("Failed with Bearer token at %s: %s", full_url, str(e))
                
                # Try with Basic Auth
                if headers3:
                    try:
                        response = requests.get(full_url, headers=headers3, timeout=10)
                        if response.status_code == 200:
                            _logger.info("Success with Basic Auth at %s", full_url)
                            results.append((response, "Basic Auth", full_url))
                            success = True
                            break
                    except Exception as e:
                        _logger.debug("Failed with Basic Auth at %s: %s", full_url, str(e))
                
                # Try with API Key as Query Parameter
                try:
                    response = requests.get(query_url + endpoint, timeout=10)
                    if response.status_code == 200:
                        _logger.info("Success with API Key query param at %s", query_url + endpoint)
                        results.append((response, "API Key query param", query_url + endpoint))
                        success = True
                        break
                except Exception as e:
                    _logger.debug("Failed with API Key query param at %s: %s", query_url + endpoint, str(e))
                
                # Try with Auth as Query Parameter
                try:
                    response = requests.get(query_url2 + endpoint, timeout=10)
                    if response.status_code == 200:
                        _logger.info("Success with auth query param at %s", query_url2 + endpoint)
                        results.append((response, "auth query param", query_url2 + endpoint))
                        success = True
                        break
                except Exception as e:
                    _logger.debug("Failed with auth query param at %s: %s", query_url2 + endpoint, str(e))
                
                # Try with Token as Query Parameter
                try:
                    response = requests.get(query_url3 + endpoint, timeout=10)
                    if response.status_code == 200:
                        _logger.info("Success with token query param at %s", query_url3 + endpoint)
                        results.append((response, "token query param", query_url3 + endpoint))
                        success = True
                        break
                except Exception as e:
                    _logger.debug("Failed with token query param at %s: %s", query_url3 + endpoint, str(e))
            
            # If we found a successful combination
            if success:
                response, method, url = results[0]
                
                # Log the successful method
                _logger.info("Successfully connected using %s at %s", method, url)
                
                try:
                    result = response.json()
                except json.JSONDecodeError:
                    # Not JSON, but still a successful connection
                    self.write({
                        'connection_status': 'connected',
                        'last_error': False,
                        'last_checked': fields.Datetime.now(),
                    })
                    return {
                        'type': 'ir.actions.client',
                        'tag': 'display_notification',
                        'params': {
                            'title': _('Connection Test'),
                            'message': _('Connection to MyOperator successful! (Using %s)') % method,
                            'sticky': False,
                            'type': 'success',
                        }
                    }
                
                # Got a JSON response
                self.write({
                    'connection_status': 'connected',
                    'last_error': False,
                    'last_checked': fields.Datetime.now(),
                })
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': _('Connection Test'),
                        'message': _('Connection to MyOperator successful! (Using %s)') % method,
                        'sticky': False,
                        'type': 'success',
                    }
                }
            
            # No successful method found
            error_message = "HTTP Error: 403 - All authentication methods failed. Please verify your API token and URL are correct."
            
            # Try a direct request to get a specific error message
            try:
                response = requests.get(api_url, headers=headers2, timeout=10)
                if response.status_code != 200:
                    error_details = f"Status Code: {response.status_code}"
                    try:
                        error_json = response.json()
                        if 'error' in error_json:
                            error_details += f", Error: {error_json['error']}"
                        elif 'message' in error_json:
                            error_details += f", Message: {error_json['message']}"
                    except:
                        error_details += f", Response: {response.text[:100]}"
                    
                    error_message = f"HTTP Error: {response.status_code} - {error_details}"
            except Exception as e:
                error_message = f"Connection Error: {str(e)}"
            
            self.write({
                'connection_status': 'failed',
                'last_error': error_message,
                'last_checked': fields.Datetime.now(),
            })
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Connection Test'),
                    'message': _('Connection failed: %s') % error_message,
                    'sticky': False,
                    'type': 'danger',
                }
            }
        except Exception as e:
            # Catch all other exceptions
            error_message = f"Unexpected error: {str(e)}"
            _logger.exception("Error in MyOperator connection test: %s", error_message)
            self.write({
                'connection_status': 'failed',
                'last_error': error_message,
                'last_checked': fields.Datetime.now(),
            })
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Connection Test'),
                    'message': _('Connection failed: %s') % error_message,
                    'sticky': False,
                    'type': 'danger',
                }
            }
    
    def _get_api_url(self):
        """
        Returns properly formatted API URL
        """
        self.ensure_one()
        # Return the base API URL - we'll add specific endpoints in each method
        return self.api_url
    
    def _get_headers(self):
        """
        Returns common headers for API requests
        """
        return {
            'Authorization': f'Bearer {self.api_token}',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
    
    def sync_calls(self):
        """
        Synchronize call logs from MyOperator
        """
        self.ensure_one()
        
        if not self.is_active:
            _logger.info("MyOperator configuration %s is not active, skipping call sync", self.name)
            return False
        
        Call = self.env['myoperator.call']
        
        try:
            # Get base API URL
            api_url = self._get_api_url()
            
            # Call logs endpoint - adjust based on actual API
            calls_endpoint = f"{api_url}/call/logs"
            
            # Prepare headers
            headers = self._get_headers()
            
            # If last sync time is available, only fetch calls after that time
            params = {'limit': 100}
            if self.last_call_sync:
                # Format datetime to MyOperator expected format - adjust format if needed
                last_sync = self.last_call_sync.strftime('%Y-%m-%d %H:%M:%S')
                params['from_date'] = last_sync
            
            # Make API call to get call logs with timeout
            response = requests.get(calls_endpoint, headers=headers, params=params, timeout=20)
            
            # Check response before parsing
            if response.status_code != 200:
                _logger.error("HTTP error when syncing calls: %s", response.status_code)
                return False
                
            # Handle possible JSON parsing errors
            try:
                result = response.json()
            except json.JSONDecodeError as e:
                _logger.error("JSON parsing error when syncing calls: %s", str(e))
                return False
            
            # Extract call data from response - adjust based on actual API response structure
            if (result.get('success') == True or 
                result.get('status') == 'success' or 
                result.get('status') == 200 or 
                result.get('code') == 200):
                
                # Get the call data array - adjust path based on actual API response
                calls_data = []
                if isinstance(result.get('data'), list):
                    calls_data = result.get('data')
                elif isinstance(result.get('data'), dict) and 'calls' in result.get('data'):
                    calls_data = result.get('data').get('calls', [])
                elif 'calls' in result:
                    calls_data = result.get('calls', [])
                elif 'records' in result:
                    calls_data = result.get('records', [])
                
                calls_count = 0
                
                for call_data in calls_data:
                    # Get the call ID - may have different key names
                    call_id = (call_data.get('id') or 
                              call_data.get('call_id') or 
                              call_data.get('uuid'))
                    
                    if not call_id:
                        _logger.warning("Call data missing ID, skipping: %s", call_data)
                        continue
                    
                    # Check if call already exists in our system
                    existing_call = Call.search([
                        ('myoperator_call_id', '=', call_id),
                    ], limit=1)
                    
                    if not existing_call:
                        # Get phone number - may have different key names
                        phone = (call_data.get('phone') or 
                                call_data.get('caller_number') or 
                                call_data.get('from') or
                                call_data.get('customer_number'))
                        
                        # Create new call record - adjust field mapping as needed
                        call_values = {
                            'myoperator_call_id': call_id,
                            'phone': phone,
                            'call_type': (call_data.get('type') or 
                                         call_data.get('call_type') or
                                         call_data.get('direction') or
                                         'incoming'),
                            'status': (call_data.get('status') or 
                                      call_data.get('call_status')),
                            'duration': (call_data.get('duration', 0) or 
                                        call_data.get('call_duration', 0)),
                            'start_time': (call_data.get('start_time') or 
                                          call_data.get('timestamp') or
                                          call_data.get('created_at')),
                            'end_time': (call_data.get('end_time') or 
                                        call_data.get('hangup_time')),
                            'recording_url': (call_data.get('recording_url', '') or 
                                            call_data.get('recording', '')),
                            'agent': (call_data.get('agent', '') or 
                                     call_data.get('agent_name', '') or
                                     call_data.get('assigned_to', '')),
                            'config_id': self.id,
                            'raw_data': json.dumps(call_data),
                        }
                        
                        # Try to find partner by phone
                        if phone:
                            partner = self.env['res.partner'].search([
                                '|',
                                ('phone', '=', phone),
                                ('mobile', '=', phone),
                            ], limit=1)
                            
                            if partner:
                                call_values['partner_id'] = partner.id
                        
                        Call.create(call_values)
                        calls_count += 1
                
                # Update last sync time
                self.write({'last_call_sync': fields.Datetime.now()})
                
                _logger.info("Successfully synchronized %s calls from MyOperator", calls_count)
                return calls_count
            else:
                error_message = (result.get('message') or 
                               result.get('error') or 
                               result.get('error_message') or 
                               'Unknown error')
                _logger.error("Failed to sync calls from MyOperator: %s", error_message)
                return False
                
        except requests.exceptions.RequestException as e:
            _logger.exception("Network error while synchronizing calls from MyOperator: %s", str(e))
            return False
        except Exception as e:
            _logger.exception("Error while synchronizing calls from MyOperator: %s", str(e))
            return False

    def sync_messages(self):
        """
        Synchronize WhatsApp messages from MyOperator
        """
        self.ensure_one()
        
        if not self.is_active:
            _logger.info("MyOperator configuration %s is not active, skipping message sync", self.name)
            return False
        
        Message = self.env['myoperator.message']
        
        try:
            # Get base API URL
            api_url = self._get_api_url()
            
            # WhatsApp messages endpoint - using the URL you provided as a hint
            messages_endpoint = f"{api_url}/whatsapp/messages"
            
            # Prepare headers
            headers = self._get_headers()
            
            # If last sync time is available, only fetch messages after that time
            params = {'limit': 100}
            if self.last_message_sync:
                # Format datetime to MyOperator expected format - adjust format if needed
                last_sync = self.last_message_sync.strftime('%Y-%m-%d %H:%M:%S')
                params['from_date'] = last_sync
            
            # Make API call to get messages with timeout
            response = requests.get(messages_endpoint, headers=headers, params=params, timeout=20)
            
            # Check response before parsing
            if response.status_code != 200:
                _logger.error("HTTP error when syncing messages: %s", response.status_code)
                return False
                
            # Handle possible JSON parsing errors
            try:
                result = response.json()
            except json.JSONDecodeError as e:
                _logger.error("JSON parsing error when syncing messages: %s", str(e))
                return False
            
            # Extract message data from response - adjust based on actual API response structure
            if (result.get('success') == True or 
                result.get('status') == 'success' or 
                result.get('status') == 200 or 
                result.get('code') == 200):
                
                # Get the message data array - adjust path based on actual API response
                messages_data = []
                if isinstance(result.get('data'), list):
                    messages_data = result.get('data')
                elif isinstance(result.get('data'), dict) and 'messages' in result.get('data'):
                    messages_data = result.get('data').get('messages', [])
                elif 'messages' in result:
                    messages_data = result.get('messages', [])
                elif 'records' in result:
                    messages_data = result.get('records', [])
                
                messages_count = 0
                
                for message_data in messages_data:
                    # Get the message ID - may have different key names
                    message_id = (message_data.get('id') or 
                                 message_data.get('message_id') or 
                                 message_data.get('uuid'))
                    
                    if not message_id:
                        _logger.warning("Message data missing ID, skipping: %s", message_data)
                        continue
                    
                    # Check if message already exists in our system
                    existing_message = Message.search([
                        ('myoperator_message_id', '=', message_id),
                    ], limit=1)
                    
                    if not existing_message:
                        # Get phone number - may have different key names
                        phone = (message_data.get('phone') or 
                                message_data.get('to') or 
                                message_data.get('customer_number') or
                                message_data.get('recipient'))
                        
                        # Create new message record - adjust field mapping as needed
                        message_values = {
                            'myoperator_message_id': message_id,
                            'phone': phone,
                            'direction': (message_data.get('direction') or 
                                         ('outbound' if message_data.get('is_outbound') else 'inbound')),
                            'message_type': (message_data.get('type') or 
                                           message_data.get('message_type') or
                                           'text'),
                            'content': (message_data.get('content') or 
                                       message_data.get('body') or
                                       message_data.get('text') or
                                       ''),
                            'status': (message_data.get('status') or 
                                      message_data.get('delivery_status')),
                            'timestamp': (message_data.get('timestamp') or 
                                         message_data.get('created_at') or
                                         message_data.get('sent_at')),
                            'media_url': (message_data.get('media_url', '') or 
                                         message_data.get('file_url', '') or
                                         message_data.get('attachment', '')),
                            'config_id': self.id,
                            'raw_data': json.dumps(message_data),
                        }
                        
                        # Try to find partner by phone
                        if phone:
                            partner = self.env['res.partner'].search([
                                '|',
                                ('phone', '=', phone),
                                ('mobile', '=', phone),
                            ], limit=1)
                            
                            if partner:
                                message_values['partner_id'] = partner.id
                        
                        Message.create(message_values)
                        messages_count += 1
                
                # Update last sync time
                self.write({'last_message_sync': fields.Datetime.now()})
                
                _logger.info("Successfully synchronized %s messages from MyOperator", messages_count)
                return messages_count
            else:
                error_message = (result.get('message') or 
                               result.get('error') or 
                               result.get('error_message') or 
                               'Unknown error')
                _logger.error("Failed to sync messages from MyOperator: %s", error_message)
                return False
                
        except requests.exceptions.RequestException as e:
            _logger.exception("Network error while synchronizing messages from MyOperator: %s", str(e))
            return False
        except Exception as e:
            _logger.exception("Error while synchronizing messages from MyOperator: %s", str(e))
            return False
            
    @api.model
    def _cron_sync_calls(self):
        """
        Cron job method to sync call logs from all active configurations
        """
        configs = self.search([
            ('is_active', '=', True),
            ('auto_sync', '=', True)
        ])
        
        for config in configs:
            try:
                _logger.info("Cron: Syncing call logs from MyOperator configuration '%s'", config.name)
                config.sync_calls()
            except Exception as e:
                _logger.exception("Error in cron job while syncing calls from MyOperator configuration '%s': %s", 
                                config.name, str(e))
    
    @api.model
    def _cron_sync_messages(self):
        """
        Cron job method to sync WhatsApp messages from all active configurations
        """
        configs = self.search([
            ('is_active', '=', True),
            ('auto_sync', '=', True)
        ])
        
        for config in configs:
            try:
                _logger.info("Cron: Syncing WhatsApp messages from MyOperator configuration '%s'", config.name)
                config.sync_messages()
            except Exception as e:
                _logger.exception("Error in cron job while syncing messages from MyOperator configuration '%s': %s", 
                                config.name, str(e))