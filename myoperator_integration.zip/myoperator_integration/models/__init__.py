from . import myoperator_config
from . import myoperator_call
from . import myoperator_message
from . import res_partner