from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
from datetime import datetime


class FleetBooking(models.Model):
    _name = 'fleet.booking'
    _description = 'Fleet Booking'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'id desc'

    name = fields.Char(string='Order Reference', required=True, copy=False, 
                       readonly=True, default=lambda self: _('New'))
    
    # Basic Info
    customer_id = fields.Many2one('res.partner', string='Customer', 
                                  required=True, tracking=True)
    customer_email = fields.Char(related='customer_id.email', string='Email')
    customer_phone = fields.Char(related='customer_id.phone', string='Phone')
    company_name = fields.Char(string='Company Name')
    # Add this to the fields in FleetBooking class
    route_id = fields.Many2one('fleet.route', string='Route')
    
    # Passenger Info
    passenger_name = fields.Char(string='Passenger Name')
    passenger_position = fields.Char(string='Passenger Position')
    passenger_email = fields.Char(string='Passenger Email')
    passenger_phone = fields.Char(string='Passenger Phone')
    passenger_count = fields.Integer(string='Passenger Count', default=0)
    
    # Status management
    state = fields.Selection([
        ('enquiry', 'Enquiry'),
        ('quotation', 'Quotation'),
        ('followup', 'Follow Up'),
        ('confirmed_pending', 'Confirmed (Lost/Cancelled)'),
        ('confirmed', 'Confirmed'),
        ('completed', 'Completed'),
        ('feedback', 'Feedback'),
    ], string='Status', default='enquiry', tracking=True)
    
    # Transport Details
    journey_start_location = fields.Char(string='Start Location', tracking=True)
    journey_end_location = fields.Char(string='End Location', tracking=True)
    via_stops = fields.Text(string='Via Stops')
    journey_distance = fields.Float(string='Distance', digits=(16, 2))
    distance_uom = fields.Selection([
        ('km', 'Kilometer'),
        ('mile', 'Mile')
    ], string='Distance UOM', default='km')
    
    journey_duration = fields.Integer(string='Duration (minutes)')
    journey_start_date = fields.Date(string='Travel Date', tracking=True)
    journey_start_time = fields.Float(string='Start Time')
    fixed_end_time = fields.Boolean(string='Fixed End Time')
    return_journey_needed = fields.Boolean(string='Return Journey Needed')
    
    # Vehicle Details
    vehicle_id = fields.Many2one('fleet.vehicle', string='Vehicle')
    vehicle_type = fields.Selection([
        ('26_seater_ac_coach', '26 Seater AC coach'),
        ('sedan', 'Sedan'),
        ('suv', 'SUV'),
        ('mini_bus', 'Mini Bus'),
        ('bus', 'Bus'),
    ], string='Vehicle Type')
    
    # Driver Assignment
    driver_id = fields.Many2one('fleet.driver', string='Assigned Driver')
    
    # Cargo Details
    cargo_type = fields.Selection([
        ('passenger', 'Passenger'),
        ('luggage', 'Luggage'),
        ('freight', 'Freight'),
    ], string='Cargo Type', default='passenger')
    suitcase_count = fields.Integer(string='Suitcase Count', default=0)
    hand_luggage_count = fields.Integer(string='Hand Luggage Count', default=0)
    cargo_manifest_id = fields.Many2one('fleet.cargo.manifest', string='Cargo Manifest')
    
    # Financial Details
    currency_id = fields.Many2one('res.currency', string='Currency', 
                                  default=lambda self: self.env.company.currency_id)
    journey_price = fields.Monetary(string='Journey Price', currency_field='currency_id')
    vat_amount = fields.Monetary(string='VAT', currency_field='currency_id')
    total_price = fields.Monetary(string='Total', compute='_compute_total_price', 
                                  store=True, currency_field='currency_id')
    
    # Payment Tracking
    payment_status = fields.Selection([
        ('not_invoiced', 'Not Invoiced'),
        ('invoiced', 'Invoiced'),
        ('partially_paid', 'Partially Paid'),
        ('paid', 'Paid'),
    ], string='Payment Status', default='not_invoiced', tracking=True)
    payment_date = fields.Datetime(string='Payment Date')
    payment_method = fields.Selection([
        ('bank_transfer', 'Bank Transfer'),
        ('cash', 'Cash'),
        ('credit_card', 'Credit Card'),
        ('other', 'Other'),
    ], string='Payment Method')
    amount_paid = fields.Monetary(string='Amount Paid', currency_field='currency_id')
    balance_amount = fields.Monetary(string='Balance', compute='_compute_balance', 
                                     store=True, currency_field='currency_id')
    
    # Notes
    notes = fields.Text(string='Order Notes')
    transport_notes = fields.Text(string='Transport Notes')
    
    # Activity tracking
    create_date = fields.Datetime(string='Created On', readonly=True)
    user_id = fields.Many2one('res.users', string='Assigned To', 
                              default=lambda self: self.env.user)
    
    # Feedback
    feedback = fields.Text(string='Customer Feedback')
    feedback_rating = fields.Selection([
        ('1', '1 Star'),
        ('2', '2 Stars'),
        ('3', '3 Stars'),
        ('4', '4 Stars'),
        ('5', '5 Stars'),
    ], string='Rating')

    # Add this field if not already present
    company_id = fields.Many2one('res.company', string='Company', 
                               default=lambda self: self.env.company)
    
    def action_generate_invoice(self):
        """Generate and show invoice"""
        self.ensure_one()
        # Update status
        self.write({'payment_status': 'invoiced'})
        
        # Return the invoice report action
        return self.env.ref('fleet_booking.action_report_fleet_booking_invoice').report_action(self)
    
    def action_view_invoice(self):
        """View the invoice"""
        self.ensure_one()
        return self.env.ref('fleet_booking.action_report_fleet_booking_invoice').report_action(self)
    
    def action_download_invoice(self):
        """Download the invoice as PDF"""
        self.ensure_one()
        return self.env.ref('fleet_booking.action_report_fleet_booking_invoice').report_action(self)

    @api.depends('journey_price', 'vat_amount')
    def _compute_total_price(self):
        for record in self:
            record.total_price = record.journey_price + record.vat_amount

    @api.depends('total_price', 'amount_paid')
    def _compute_balance(self):
        for record in self:
            record.balance_amount = record.total_price - record.amount_paid

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', _('New')) == _('New'):
                vals['name'] = self.env['ir.sequence'].next_by_code('fleet.booking') or _('New')
        return super(FleetBooking, self).create(vals_list)

    def action_quotation(self):
        self.write({'state': 'quotation'})

    def action_followup(self):
        self.write({'state': 'followup'})

    def action_confirm(self):
        self.write({'state': 'confirmed'})

    def action_lost_cancelled(self):
        self.write({'state': 'confirmed_pending'})

    def action_complete(self):
        self.write({'state': 'completed'})

    def action_feedback(self):
        self.write({'state': 'feedback'})

    def action_reset_to_enquiry(self):
        self.write({'state': 'enquiry'})

    def action_assign_driver(self):
        return {
            'name': _('Assign Driver'),
            'type': 'ir.actions.act_window',
            'res_model': 'fleet.driver.assign.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {'default_booking_id': self.id},
        }

    def action_register_payment(self):
        return {
            'name': _('Register Payment'),
            'type': 'ir.actions.act_window',
            'res_model': 'fleet.payment.register.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {'default_booking_id': self.id, 'default_amount': self.balance_amount},
        }

    def action_generate_invoice(self):
        # Logic to generate invoice
        self.write({'payment_status': 'invoiced'})
        return {'type': 'ir.actions.act_window_close'}

    def action_view_route(self):
        return {
            'name': _('Journey Route'),
            'type': 'ir.actions.act_window',
            'res_model': 'fleet.route',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_start_location': self.journey_start_location,
                'default_end_location': self.journey_end_location,
                'default_via_stops': self.via_stops,
            },
        }