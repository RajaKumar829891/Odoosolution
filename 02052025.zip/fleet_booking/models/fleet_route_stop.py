from odoo import api, fields, models

class FleetRouteStop(models.Model):
    _name = 'fleet.route.stop'
    _description = 'Route Stop'
    _order = 'sequence, id'
    
    route_id = fields.Many2one('fleet.route', string='Route', required=True, ondelete='cascade')
    sequence = fields.Integer(string='Sequence', default=10)
    name = fields.Char(string='Location Name', required=True)
    latitude = fields.Float(string='Latitude', digits=(16, 8))
    longitude = fields.Float(string='Longitude', digits=(16, 8))
    distance = fields.Float(string='Distance', digits=(16, 2))
    duration = fields.Integer(string='Duration (minutes)')
    stop_type = fields.Selection([
        ('pickup', 'Pickup'),
        ('dropoff', 'Drop-off'),
        ('waypoint', 'Waypoint'),
        ('rest', 'Rest Stop'),
    ], string='Stop Type', default='waypoint')
    notes = fields.Text(string='Notes')