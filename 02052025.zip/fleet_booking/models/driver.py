from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class FleetDriver(models.Model):
    _name = 'fleet.driver'
    _description = 'Fleet Driver'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'name'

    name = fields.Char(string='Driver Name', required=True, tracking=True)
    employee_id = fields.Many2one('hr.employee', string='Related Employee', ondelete='set null')
    user_id = fields.Many2one('res.users', string='Related User', ondelete='set null')
    
    # Contact information
    mobile = fields.Char(string='Mobile', tracking=True)
    email = fields.Char(string='Email', tracking=True)
    address = fields.Text(string='Address')
    
    # Personal identification
    identification_no = fields.Char(string='ID Number', tracking=True)
    passport_no = fields.Char(string='Passport Number')
    
    # License information
    license_number = fields.Char(string='License Number', required=True, tracking=True)
    license_type = fields.Selection([
        ('a', 'A - Motorcycle'),
        ('b', 'B - Car'),
        ('c', 'C - Commercial'),
        ('d', 'D - Bus/Coach'),
        ('e', 'E - Heavy Vehicle'),
    ], string='License Type', required=True, tracking=True)
    license_expiry = fields.Date(string='License Expiry Date', tracking=True)
    
    # Additional qualifications
    has_first_aid_cert = fields.Boolean(string='First Aid Certificate', default=False)
    has_dangerous_goods_cert = fields.Boolean(string='Dangerous Goods Certificate', default=False)
    has_passenger_transport_cert = fields.Boolean(string='Passenger Transport Certificate', default=False)
    additional_qualifications = fields.Text(string='Additional Qualifications')
    
    # Availability and status
    active = fields.Boolean(string='Active', default=True, tracking=True)
    available = fields.Boolean(string='Available Now', default=True, tracking=True)
    state = fields.Selection([
        ('available', 'Available'),
        ('on_trip', 'On Trip'),
        ('on_leave', 'On Leave'),
        ('inactive', 'Inactive'),
    ], string='Status', default='available', tracking=True)
    
    # Relations
    vehicle_ids = fields.Many2many(
        'fleet.vehicle', 
        'fleet_driver_vehicle_rel', 
        'driver_id', 
        'vehicle_id', 
        string='Qualified Vehicles'
    )
    preferred_vehicle_id = fields.Many2one(
        'fleet.vehicle', 
        string='Preferred Vehicle', 
        ondelete='set null'
    )
    booking_ids = fields.One2many(
        'fleet.booking', 
        'driver_id', 
        string='Assigned Bookings'
    )
    booking_count = fields.Integer(
        string='Booking Count', 
        compute='_compute_booking_count', 
        default=0
    )
    
    # Performance tracking
    rating = fields.Float(string='Rating', digits=(2, 1), default=5.0)
    total_trips = fields.Integer(string='Total Trips', compute='_compute_trip_stats', store=True, default=0)
    completed_trips = fields.Integer(string='Completed Trips', compute='_compute_trip_stats', store=True, default=0)
    cancelled_trips = fields.Integer(string='Cancelled Trips', compute='_compute_trip_stats', store=True, default=0)
    
    # Notes
    notes = fields.Text(string='Notes')
    
    @api.depends('booking_ids')
    def _compute_booking_count(self):
        for driver in self:
            driver.booking_count = len(driver.booking_ids) if driver.booking_ids else 0
    
    @api.depends('booking_ids', 'booking_ids.state')
    def _compute_trip_stats(self):
        for driver in self:
            if not driver.booking_ids:
                driver.total_trips = 0
                driver.completed_trips = 0
                driver.cancelled_trips = 0
                continue
                
            driver.total_trips = len(driver.booking_ids)
            driver.completed_trips = len(driver.booking_ids.filtered(lambda b: b.state == 'completed'))
            driver.cancelled_trips = len(driver.booking_ids.filtered(lambda b: b.state == 'cancelled'))
    
    @api.constrains('license_expiry')
    def _check_license_expiry(self):
        for driver in self:
            if driver.license_expiry and driver.license_expiry < fields.Date.today():
                raise ValidationError(_("The driver's license has expired!"))
    
    def action_view_bookings(self):
        self.ensure_one()
        return {
            'name': _('Driver Bookings'),
            'type': 'ir.actions.act_window',
            'res_model': 'fleet.booking',
            'view_mode': 'tree,form',
            'domain': [('driver_id', '=', self.id)],
            'context': {'default_driver_id': self.id},
        }
    
    def action_set_available(self):
        self.write({'state': 'available', 'available': True})
    
    def action_set_on_trip(self):
        self.write({'state': 'on_trip', 'available': False})
    
    def action_set_on_leave(self):
        self.write({'state': 'on_leave', 'available': False})
    
    def action_set_inactive(self):
        self.write({'state': 'inactive', 'available': False, 'active': False})